#include <iostream>
#include "hello.h"

void hello() {
    std::cout << "Hello World!\n";
    return;
}
